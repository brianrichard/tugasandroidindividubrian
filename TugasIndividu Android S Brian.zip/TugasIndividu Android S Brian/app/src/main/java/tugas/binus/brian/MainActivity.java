package tugas.binus.brian;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button calculateBtn = (Button) findViewById(R.id.calculateBtn);
        calculateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText firstNumEditText = (EditText) findViewById(R.id.firstNumberEditText);
                TextView resultTextView = (TextView) findViewById(R.id.resultTextView);

                int dollar = Integer.parseInt(firstNumEditText.getText().toString());
                int a = 14125;
                int result = dollar * a;
                resultTextView.setText("Rp. " + result + "");
            }

        });
        Button calculateBtn2 = (Button) findViewById(R.id.calculateBtn2);
        calculateBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText secondNumEditText = (EditText) findViewById(R.id.secondNumberEditText);
                TextView resultTextView = (TextView) findViewById(R.id.resultTextView);

                int pounds = Integer.parseInt(secondNumEditText.getText().toString());
                int b = 19672;
                int result = pounds * b;
                resultTextView.setText("Rp. " + result + "");
            }
        });
        Button calculateBtn3 = (Button) findViewById(R.id.calculateBtn3);
        calculateBtn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText thirdNumberEditText = (EditText) findViewById(R.id.thirdNumberEditText);
                TextView resultTextView = (TextView) findViewById(R.id.resultTextView);

                int ringgit = Integer.parseInt(thirdNumberEditText.getText().toString());
                int c = 3750;
                int result = ringgit * c;
                resultTextView.setText("Rp. " + result + "");
            }
        });
        Button calculateBtn4 = (Button) findViewById(R.id.calculateBtn4);
        calculateBtn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText fourthNumberEditText = (EditText) findViewById(R.id.fourthNumberEditText);
                TextView resultTextView = (TextView) findViewById(R.id.resultTextView);

                int baht = Integer.parseInt(fourthNumberEditText.getText().toString());
                int d = 503;
                int result = baht * d;
                resultTextView.setText("Rp. " + result + "");
            }
        });
    }

}
